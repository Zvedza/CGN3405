# cgn3405
Applied Numerical Methods in Civil Engineering

This repository is for students taking my CGN 3405 Applied Numerical Methods Course at UCF.
